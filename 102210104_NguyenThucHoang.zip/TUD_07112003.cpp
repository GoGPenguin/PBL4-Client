#include <iostream>
#include <bits/stdc++.h>
using namespace std;


//f(x) = (e^(2x) + x - 10)^2 + 2(x+1)^2


double f(double x) {
    double term1 = pow(exp(2 * x) + x - 10, 2);
    double term2 = 2 * pow(x + 1, 2);
    return term1 + term2;
}




double f_prime(double x) {
    double term1 = 2 * (exp(2 * x) + x - 10) * (2 * exp(2 * x) + 1);
    double term2 = 4 * (x + 1);
    return term1 + term2;
}

double f_double_prime(double x) {
    double term1 = 2 * (8 * exp(4 * x) + 4 * x* exp(2 * x) - 36*exp(2*x) + 1);
    return term1 + 4;
}


//f(x) = (e^(2x^2+1) - 2x + 1)^2-5(x+1)^3
double f2(double x)
{
	double term1 = pow(exp(2 * pow(x, 2) + 1) - 2 * x + 1, 2);
    double term2 = 5 * pow(x + 1, 3);
    return term1 - term2;
}

double f2_prime(double x)
{
	 double term1 = 2 * (exp(2 * pow(x, 2) + 1) - 2 * x + 1) * (2 * exp(2 * pow(x, 2) + 1) * 2 * x - 2);
    double term2 = 15 * pow(x + 1, 2);
    return term1 - term2;
}
long long f2_double_prime(double x) {
    long long term1 = 2 * (32*pow(x,2)*exp(4*pow(x,2) + 2) - 24*x*exp(2*pow(x,2) + 1) + 4*exp(4*pow(x,2) + 2) - 32*pow(x,3)*exp(2*pow(x,2) + 1) + 4*exp(2*pow(x,2) + 1) + 16*pow(x,2)*exp(2*pow(x,2) + 1));
    long long term2 = 30 * (x + 1);
    return term1 - term2;
}

double gradient_descent(double x_init, double gamma, int n_iter=10000, double tol=1e-7) {
    double x = x_init;
    for (int i = 0; i < n_iter; ++i) {
        double grad = f_prime(x);
        double x_new = x - gamma*grad;
        if (abs(x_new - x) < tol) {
            break;
        }
        x = x_new;
    }
    return x;
}

double momentum(double x_init, double gamma, double alpha, int n_iter=10000, double tol=1e-7) {
    double x = x_init;
    double v = 0;
    for (int i = 0; i < n_iter; ++i) {
        double grad = f_prime(x);
        v = alpha*v + gamma*grad;
        double x_new = x - v;
        if (abs(x_new - x) < tol) {
            break;
        }
        x = x_new;
    }
    return x;
}

double newton_method(double x_init, int n_iter=10000, double tol=1e-6) {
    double x = x_init;
    for (int i = 0; i < n_iter; ++i) {
        double grad = f_prime(x);
        double hessian = f_double_prime(x);
        double x_new = x - grad / hessian;
        if (abs(x_new - x) < tol) {
            break;
        }
        x = x_new;
    }
    return x;
}
int main() {
    double x = 0.5; 
    cout << "f(x) = (e^(2x) + x - 10)^2 + 2(x+1)^2" << endl;
    double result = f(x);
    cout << "f(" << x << ") = " << result << endl;


    double prime_result = f_prime(x);
    cout << "f'(" << x << ") = " << prime_result << endl;


    double double_prime_result = f_double_prime(x);
    cout << "f''(" << x << ") = " << double_prime_result << endl;

	cout << "f(x) = (e^(2x^2+1) - 2x + 1)^2-5(x+1)^3" << endl;
	
	double y = 0.2;
	
	long long result2 = f2(y);
    cout << "f(" << y << ") = " << result2 << endl;


    long long prime_result2 = f2_prime(y);
    cout << "f'(" << y << ") = " << prime_result2 << endl;


    long long double_prime_result2 = f2_double_prime(y);
    cout << "f''(" << y << ") = " << double_prime_result2 << endl;
    
    
    
    //gradient descend
    //f(x) = (e^(2x) + x - 10)^2 + 2(x+1)^2
	cout << "Gradient_descent: x = " << gradient_descent(x,0.001) << "\n";
    cout << "Momentum: x = " << momentum(x,0.001,0.9) << "\n";
    cout << "Newton: x = " << newton_method(x) << "\n";
    
    return 0;
}

